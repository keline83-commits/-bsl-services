BSL Services website
=====================

Files:
- index.html — the website
- styles.css — design and responsive layout

To publish it free:
1. Create a free account on GitHub.
2. Create a new repository named bsl-services.
3. Upload index.html and styles.css.
4. In the repository, open Settings -> Pages.
5. Choose "Deploy from a branch", select the main branch and root folder.
6. Save. GitHub will provide your free website address.

The site currently says "Open for appointments" and uses:
Phone: 07984 495997
Email: bslservices2012@hotmail.com
Areas: Central London & Greater London

Before publishing, add your own real photos, reviews and any claims (such as insurance or guarantees) only if they are accurate.
